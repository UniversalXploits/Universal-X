If you are experiencing errors while using Universal X contact ThisNameWasTaken2.0#1845 on discord and i will try to help you to fix the error.
Also report bugs if you find any :)
Have fun exploiting!